import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import { ChamberHorcus } from "./components/ChamberHorcus";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ChamberHorcus />
  </React.StrictMode>,
);

# Chamber // Archivo 044

Versión independiente del mockup React de Chamber, preparada para Vite/Vercel.

## Importante
Copia la imagen original de Replit `chamber-official.png` en:
`public/images/chamber-official.png`

El componente ya usa `/images/chamber-official.png`, no la ruta especial `__mockup` de Replit.

## Ejecutar
```bash
npm install
npm run dev
```

## Producción
```bash
npm run build
npm run preview
```

Después puedes subir el proyecto a GitHub e importarlo en Vercel.
